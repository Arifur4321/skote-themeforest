<?php

namespace App\Http\Controllers;

use App\Models\Project;
use Illuminate\Http\Request;

class ProjectController extends Controller
{
    public function saveProject(Request $request)
    {
        // Validate the request data
        $request->validate([
            'projectName' => 'required|string',
            'dueDate' => 'required|date',
            'status' => 'required|string',
            'team' => 'required|string',
            'action' => 'required|string',
        ]);

        // Save the project data
        Project::create($request->all());

        // Return a JSON response indicating success
        return response()->json(['message' => 'Project saved successfully'], 200);
    }
}
